# Fixtures: D-Bus replies

These are plain JSON with the Variants already unwrapped. Tests feed them into the pure parsers,
or into a fake bus that answers method calls from them. No test talks to a real bus: `conftest.py`
points `DBUS_SYSTEM_BUS_ADDRESS` at a socket that doesn't exist.

- **`bluez-managed-objects.json`**: what `org.bluez` `/` `ObjectManager.GetManagedObjects`
  returns. One powered adapter; a connected headset with `Battery1` at 80 %; a connected mouse
  with no battery interface; and a paired phone that isn't connected. The addresses are from the
  documentation range `00:00:5E:00:53:xx`.
- **`nm-wifi.json`**: NetworkManager properties keyed by object path and then interface. There
  are three devices (`lo`, `docker0`, and the Wi-Fi device `wlp99s0` with `DeviceType` 2) and
  two access points: the active one at 72 %, and a second at 51 % that tests roam to.
