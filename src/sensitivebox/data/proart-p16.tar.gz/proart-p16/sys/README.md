# Fixture: ASUS ProArt P16 (Ryzen AI, Radeon iGPU, MT7925 Wi-Fi)

A hand-built fake `/sys` tree. Pass this directory as `sysfs_root`.

- **Layout** mirrors the kernel: `class/hwmon/hwmonN` are relative symlinks into `devices/…`, and
  every hwmon directory has a relative `device` symlink to its parent device, so stable IDs
  (`<chip>/<bus id>/<channel>`) resolve exactly as on the real machine. The hwmon numbers, symlink
  targets and set of files were copied from the reference machine on Ubuntu 26.04.
- **Values** come from the "Reference readout" table in `docs/BIBLE.md`, in raw sysfs units:
  millidegrees, millivolts, milliamps, microwatts, Hz and RPM.
- **Awkward cases on purpose:**
  - `asus` `pwm1`–`pwm3` read `-ENODATA` on the real machine. A plain file can't return an errno,
    so these files contain the marker `<ENODATA>`; the test suite's opener raises
    `OSError(errno.ENODATA)` for them. Read naively, the marker is non-numeric, which is also
    reported as unavailable.
  - `nvme` `temp2` ("Sensor 1") has junk limits: max 65 261 850 m°C and min −273 150 m°C.
  - USB-C port `USBC000:002` reads 0 V / 0 A, and the `amdgpu` rails read 0 V at idle. Zero is a
    valid reading, not junk.
  - `ACAD` has no sensors; `asus_custom_fan_curve` has only `pwm*_auto_point*` and `pwm*_enable`
    files, which are not sensors.

## System sources (beyond hwmon)

This machine's `sys/`, `proc/` and `dbus/` components are self-contained; select their parent
with hidden `--root` for isolated CLI runs.

- **`class/net/`**: `lo` and `docker0` are symlinks under `devices/virtual/net`, and `wlp99s0`
  is under the Wi-Fi card's PCI device. Each has `statistics/{rx,tx}_bytes` and `operstate`.
  `lo` and `docker*` are skipped by default.
- **`class/power_supply/`**: relative symlinks to the four supplies, which also hold the hwmon
  directories above. `BAT1` is at 64 % and `Charging`. `ACAD` is online. USB-C port `:001` is
  online at 5 V / 1.5 A (7.5 W, a slow charger) and `:002` is empty (`online` 0, 0 V / 0 A).
  Voltage and current are in micro-units, as in the kernel. The directory names use hyphens
  (`ucsi-source-psy-…`); only the hwmon chip name uses underscores.
- **`devices/system/cpu/cpu0–23/cpufreq/`**: amd-pstate values in kHz. Eight cores reach
  5.16 GHz and sixteen compact cores reach 3.3 GHz. The `cpufreq/` and `cpuidle/` siblings are
  not CPUs.
- **`fs/cgroup/user.slice/user-1000.slice/user@1000.service/app.slice/`**: one directory per
  app with `memory.current`, using real systemd unit name shapes. They include escaped names
  (`google\x2dchrome`), launcher prefixes (`gnome`, `flatpak`), a template `@` instance, a
  `.slice`, a terminal `ptyxis-spawn-…` scope and a plain `.service`. Chrome appears twice,
  under two different app IDs, as it does on the real machine.
- No `block/zram*` here: the P16 has no zram. See `../../zram/sys/`.
